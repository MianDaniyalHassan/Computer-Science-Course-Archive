#include<iostream>
using namespace std;
int main()
{
int myArray[10];
int x ;
int chk = -1;
for(int i = 0 ; i < 7 ; i++)
{
cout<<"Idex = "<<i<<endl;
cin>>myArray[i];
}
cout<<"Which value do you wanna search:";
cin>>x;
for(int i = 0 ; i < 7 ; i++)
{
if(myArray[i]==x)
{
cout<<"Number is found on Index "<<i<<endl;
chk++;
break;
}
}
if(chk==-1)
{
cout<<"Index not found"<<endl;
}
}
