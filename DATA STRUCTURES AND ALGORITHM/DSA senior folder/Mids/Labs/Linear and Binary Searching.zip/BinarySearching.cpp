#include<iostream>
using namespace std;
int main()
{
int myArray[6];
int chk= -1;
for(int i = 0 ; i < 6 ; i++)
{
cout<<"Idex = "<<i<<endl;
cin>>myArray[i];
}
int x ;
cout<<"Which value do you wanna search:";
cin>>x;
int start = 0;
int end = 5;
int mid ;
while(start<=end)
{
mid=(start+end)/2;
if(myArray[mid]==x)
{
cout<<"Number is found on Index "<<mid<<endl;
chk++;
break;
}
else
{
if(x>=myArray[mid])
{
start=mid+1;
}
else
{
end=mid-1;
}
}
}
if(start>end)
{
cout<<"Index not found "<<endl;
}
return 0;
}
