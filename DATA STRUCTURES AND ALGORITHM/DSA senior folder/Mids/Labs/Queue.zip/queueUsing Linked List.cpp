#include<iostream>
using namespace std;
struct node
{
int value;
node* next;
};
node* front = NULL;
node* rear = NULL;
void Enque()
{
node* newNode = new node;
cout<<"Enter the value you wanna enque: ";
cin>>newNode->value;
newNode->next=NULL;
if(front==NULL)
{
front = rear = newNode;
}
else
{
rear->next=newNode;
rear=newNode;
}
}
void deque()
{
if(front==NULL)
{
cout<<"Que is empty "<<endl;
}
else
{
node* temp = front;
front=front->next;
delete temp;
}
}
void TOP()
{
if(front==NULL)
{
cout<<"Que is empty "<<endl;
}
else
{
cout<<"Front is "<<front->value<<endl;
}
}
void display()
{
if(front==NULL)
{
cout<<"Que is empty "<<endl;
}
else
{
node* temp = front ;
while(temp!=NULL)
{
cout<<temp->value<<" ";
temp=temp->next;
}
cout<<endl;
}
}
int main()
{
Enque();
Enque();
Enque();
Enque();
deque();
deque();
TOP();
display();
}
