#include<iostream>
using namespace std;
void printArray(int Arr[])
{
for(int i = 0 ; i < 5 ; i ++)
{
cout << Arr[i]<<" ";
}
}
void bubbleSort(int A[],int n)
{
for(int i = 0 ; i < n-1 ; i++)
{
for(int j = 0 ; j < n-1-i ; j++)
{
if(A[j]>A[j+1])
{
int temp = A[j];
A[j]=A[j+1];
A[j+1]=temp;
}
}
}
}
int main()
{
int a[5];
int n = 5;
for(int i = 0 ; i < 5 ; i ++)
{
cin >> a[i];
}
cout<<"\nUnSorted Array"<<endl;
printArray(a);
bubbleSort(a,n);
cout<<endl;
printArray(a);
}
