#include<iostream>
#include<string>
#define n 50  // Define the stack size
using namespace std;

char stack[n];
int top = -1;

void push(char c);
char pop();
bool isPalindrome(string str);

int main() {
    string str;
    cout << "Enter a string to check if it's a palindrome: ";
    cin >> str;

    if (isPalindrome(str)) {
        cout << "The string \"" << str << "\" is a palindrome." << endl;
    } else {
        cout << "The string \"" << str << "\" is not a palindrome." << endl;
    }

    return 0;
}

// Function to push a character onto the stack
void push(char c) {
    if (top == n - 1) {
        cout << "Stack overflow, cannot push more characters." << endl;
    } else {
        top++;
        stack[top] = c;
    }
}

// Function to pop a character from the stack
char pop() {
    if (top == -1) {
        cout << "Stack underflow, cannot pop any characters." << endl;
        return '\0';
    } else {
        char c = stack[top];
        top--;
        return c;
    }
}

// Function to check if the string is a palindrome
bool isPalindrome(string str) {
    // Push all characters of the string onto the stack
    for (int i = 0; i < str.length(); i++) {
        push(str[i]);
    }

    // Compare characters from stack with original string
    for (int i = 0; i < str.length(); i++) {
        if (pop() != str[i]) {
            return false;  // Not a palindrome if there's a mismatch
        }
    }
    return true;  // The string is a palindrome
}

