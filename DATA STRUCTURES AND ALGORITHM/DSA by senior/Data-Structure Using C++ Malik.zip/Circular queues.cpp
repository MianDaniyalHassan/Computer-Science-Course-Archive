
#include<iostream>
using namespace std;
#define N 5

int q[N];
int front = -1;
int rear = -1;
void enque()
{
	int x;
	cout<<"Enter value you wanna Enque: ";
	cin>>x;
	if(rear == N-1 && front == 0 || front == rear+1)
	{
		cout<<"Queue is full"<<endl;
	}
	else if(rear==N-1)
	{
		rear=0;
		q[rear]=x;
	}
	else if(front == -1 && rear == -1)
	{
		rear = front = 0;
		q[rear]=x;
	} 
	else
	{
		rear++;
		q[rear]=x;
	}
}

void deque()
{
	if(rear==-1 && front ==-1)
	{
		cout<<"Queue is empty"<<endl;
	}
	else if (front == rear)
	{
		cout<<"Deleted value: "<<q[front];
		rear = front = -1;
	}
	else if ( front == N-1)
	{
		cout<<"Deleted value: "<<q[front];
		front=0;
	}
	else
	{
		cout<<"Deleted value: "<<q[front];
		front++; 
	}
}

void Front()
{
	if(rear==-1 && front ==-1)
	{
		cout<<"Queue is empty"<<endl;
	}
	else
	{
		cout<<"Current Front is: "<<q[front];
	}
}

void display()
{
	if(rear==-1 && front ==-1)
	{
		cout<<"Queue is empty"<<endl;
		return;
	}

	int i = front ;
	while(i!=rear)
	{
		cout<<q[i]<<" ";
		i=(i+1)%N; 
	}
	cout<<q[rear]<<" ";
}

int main(int argc, char** argv)
{
	int choice;
	do 
	{
		cout<<"\n1: Enque(): "<<endl;
		cout<<"2: deque(): "<<endl;
		cout<<"3: front(): "<<endl;
		cout<<"4: Display(): "<<endl;
		cout<<"0: Exit(): "<<endl;
		cin>>choice;

		switch(choice)
		{
			case 1:
			{
				enque();
				break;
			}
			case 2:
			{
				deque(); 
				break;
			}
			case 3:
			{
				Front();
				break;
			}
			case 4:
			{
				display();
				break;
			}
		}
	}while(choice!=0);
	return 0;
}
