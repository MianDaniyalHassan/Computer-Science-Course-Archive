#include<iostream>
using namespace std;
struct node
{
	int value;
	node*left;
	node*right;
};

node* Getnewnode(int value) 
{
	node* newnode = new node();
	newnode->value=value;
	newnode->left=NULL;
	newnode->right=NULL;
	return newnode;
}
// To insert data in BST, returns address of root node 	
node* insert(int data , node* root)
{
	if(root==NULL)
	{
		root=Getnewnode(data);
		return root;
	}
	// if data to be inserted is lesser, insert in left subtree.
	else if(data<=root->value)
	{
		root->left=insert(data,root->left);
		return root;
	}
	// else, insert in right subtree. 
	else
	{
		root->right = insert(data,root->right);
		return root;
	} 
}
void inOrder(node* root)
{
	if(root==NULL)
	{
		return;
	}
	inOrder(root->left);
	cout<<root->value<<" ";
	inOrder(root->right);
}

bool Search(int value,node* root) {
	if(root == NULL) {
		return false;
	}
	else if(root->value == value) {
		return true;
	}
	else if(value <= root->value) {
		return Search(value,root->left);
	}
	else {
		return Search(value,root->right);
	}
}

int main() {

	node* root = NULL;  // Creating an empty tree

	/*Code to test the logic*/
	root = insert(15,root);	

	root = insert(10,root);	
	root = insert(20,root);
	root = insert(25,root);
	root = insert(8,root);
	root = insert(12,root);
	cout<<"\n-------------------------------------------------------------------------------------------------------------";
	cout<<"\nInorder Traversal: ";
	inOrder(root);
	
	// Ask user to enter a number.  
	int number;
	cout<<"\n Enter the number to be searched\n";
	cin>>number;
	//If number is found, print "FOUND"
	if(Search(number,root) == true) 
		cout<<"Found\n";
	else 
		cout<<"Not Found\n";
	return 0;
}
