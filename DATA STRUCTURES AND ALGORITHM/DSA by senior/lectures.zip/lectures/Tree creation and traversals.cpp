#include<iostream>
using namespace std;
struct node
{
	int value;
	node*left;
	node*right;
};
node* create()
{
	int x;
	cout<<"Enter the value for node (-1 for no node): ";
	cin>>x;
	node* newnode = new node();
	if(x==-1) 
	{
		return 0;
	}
	newnode->value=x;
	cout<<"Enter Left chid of "<<x<<" ";
	newnode->left=create();
	cout<<"Enter Right chid of "<<x<<" ";
	newnode->right=create();
	return newnode;
}

void preOrder(node* root)
{
	if(root==NULL)
	{
		return;
	}
	cout<<root->value<<" ";
	preOrder(root->left);
	preOrder(root->right);
}

void postOrder(node*root)
{
	if(root==NULL)
	{
		return;
	}
	postOrder(root->left);
	postOrder(root->right);
	cout<<root->value<<" ";
}

void inOrder(node* root)
{
	if(root==NULL)
	{
		return;
	}
	inOrder(root->left);
	cout<<root->value<<" ";
	inOrder(root->right);
}


node* search(int value,node*root)
{
	if(root==NULL)
	{
		cout<<"Value not found ";
		return 0;
	}

	if(root->value==value)
	{
		cout<<"Value Found ";
		return root;
	} 

	if(value<root->value)
	{
		return search(value,root->left);
	}
	
	if(value>root->value)
	{
		return search(value,root->right);
	}
}


int main()
{
	node* root = 0; 
	root = create();
	cout<<"\n-------------------------------------------------------------------------------------------------------------";
	cout<<"\nPreorder Traversal: ";
	preOrder(root);
	cout<<"\nPostOrder Traversal: ";
	postOrder(root);
	cout<<"\nInOrder Traversal: ";
	inOrder(root);
	cout<<"\n";
	search(9,root);
	return 0;
}
