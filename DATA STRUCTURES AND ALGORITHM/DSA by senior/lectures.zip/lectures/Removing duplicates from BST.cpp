#include <iostream>
#include <cstdlib>
using namespace std;

struct TreeNode {
    int* data;
    TreeNode* left;
    TreeNode* right;
};

TreeNode* createTreeNode(int* data) {
    TreeNode* newNode = new TreeNode();
    newNode->data = data;
    newNode->left = NULL;
    newNode->right = NULL;
    return newNode;
}

void insert(TreeNode* root, int* info) {
    TreeNode* node = createTreeNode(info);
    TreeNode* p = root;
    TreeNode* q = root;

    while (*info != *(p->data) && q != NULL) {
        p = q;
        if (*info < *(p->data))
            q = p->left;
        else
            q = p->right;
    }

    if (*info == *(p->data)) {
        cout << "attempt to insert duplicate: " << *info << endl;
        delete node;
    } else if (*info < *(p->data))
        p->left = node;
    else
        p->right = node;
}

int main() {
    int x[] = { 14, 15, 4, 9, 7, 18, 3, 5, 16, 4, 20, 17, 9, 14, 5, -1 };
    TreeNode* root = createTreeNode(&x[0]);

    for (int i = 1; x[i] > 0; i++) {
        insert(root, &x[i]);
    }

    return 0;
}

